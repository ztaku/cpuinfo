import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class cpuinfo extends PApplet {

//
// Disp cpuinfo
//

String [] items = {
  "vendor_id",
  "model name",
  "cpu MHz",
  "cache size", 
  "cpu cores" 
};

StringList lines = new StringList();
StringList strout= new StringList();  // shell output
StringList strerr= new StringList();   // shell error


public void search() {
//
// exsample
// vendor_id  : GenuineIntel
// model name  : Intel(R) Core(TM)2 Duo CPU     T8100  @ 2.10GHz
// cpu MHz    : 2108.309
// cache size  : 3072 KB
// cpu cores  : 2
//

  for(String el:strout) {
    for(String item:items) {
    
      if ( el.indexOf(item)  >= 0 ) {
        println( el);
        lines.append(el);
        if ( item == "cpu cores" ) {
          return;
        }
      }
    }
  }
}

public void setup() {
   
   background(0);
   
   shell(strout,strerr,"cat /proc/cpuinfo"); //shell execute
   search();
}

public void draw() {
  textSize(40);
  text("cpu info", 50, 40);
  textSize(22);
   for (int i = 0 ; i < lines.size(); i++) {
     String line =  lines.get(i);
     String [] word = split(line,":");
     int y =  i*40+100;
     text(word[0],10,y);
     text(word[1],150,y);
   }
}
  public void settings() {  size(900, 426); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "cpuinfo" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
